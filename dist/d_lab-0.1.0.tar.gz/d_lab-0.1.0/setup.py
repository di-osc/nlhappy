# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['d_lab',
 'd_lab.callbacks',
 'd_lab.configs',
 'd_lab.datamodules',
 'd_lab.layers',
 'd_lab.layers.attention',
 'd_lab.layers.classifier',
 'd_lab.layers.embedding',
 'd_lab.layers.loss',
 'd_lab.layers.normalization',
 'd_lab.metrics',
 'd_lab.models',
 'd_lab.models.sentence_pair_classification',
 'd_lab.models.span_classification',
 'd_lab.models.text_classification',
 'd_lab.models.text_multi_classification',
 'd_lab.models.token_classification',
 'd_lab.models.triple_extraction',
 'd_lab.spacy_components',
 'd_lab.tricks',
 'd_lab.utils']

package_data = \
{'': ['*'],
 'd_lab.configs': ['callbacks/*',
                   'datamodule/*',
                   'experiment/*',
                   'hparams_search/*',
                   'logger/*',
                   'mode/*',
                   'model/*',
                   'trainer/*']}

install_requires = \
['datasets>=1.18.3,<2.0.0',
 'hydra-colorlog>=1.1.0,<2.0.0',
 'hydra-core>=1.1.1,<2.0.0',
 'hydra-optuna-sweeper>=1.1.2,<2.0.0',
 'jieba>=0.42.1,<0.43.0',
 'oss2>=2.15.0,<3.0.0',
 'pytorch-lightning>=1.5.10,<2.0.0',
 'rich>=11.2.0,<12.0.0',
 'scikit-learn>=1.0.2,<2.0.0',
 'spacy>=3.2.2,<4.0.0',
 'torch>=1.10.2,<2.0.0',
 'transformers>=4.16.2,<5.0.0',
 'wandb>=0.12.10,<0.13.0']

entry_points = \
{'console_scripts': ['d-lab = d_lab.run:train'],
 'spacy_factories': ['sent_spancat = d_lab.spacy_components:make_sent_spancat']}

setup_kwargs = {
    'name': 'd-lab',
    'version': '0.1.0',
    'description': '深度学习实验室',
    'long_description': None,
    'author': 'good-as-water',
    'author_email': '790990241@qq.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
}


setup(**setup_kwargs)
