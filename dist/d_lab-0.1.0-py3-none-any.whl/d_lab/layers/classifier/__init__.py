from .global_pointer import GlobalPointer, EfficientGlobalPointer
from .simple_dense import SimpleDense
from .crf import CRF