from datasets.features import Features
from datasets import Sequence, Value, Dataset 
from typing import List, Type
from spacy.tokens import Doc
from d_lab.utils.data import Triple
from rich.progress import track

dataset_features = Features(
    {
    'text': Value('string'),  
    'label': Value('string'),
    'labels':Sequence(Value('string')),
    'spans': Sequence({'offset':Sequence(Value('int8')), 'label': Value('string'), 'text': Value('string')}),
    'tokens': Sequence({'offset':Sequence(Value('int8')),'label':Value('string'), 'text': Value('string')}),
    'triples': Sequence({'subject': {'offset':Sequence(Value('int8')), 'text':Value('string')}, 'predicate': Value('string'), 'object': {'offset':Sequence(Value('int8')), 'text':Value('string')}})
        }
)


def convert_docs_to_dataset(docs: List[Doc]) -> Dataset:
    """
    Convert a document to a dataset.
    """
    d = {'text':[], 'labels':[],  'spans':[], 'tokens':[], 'triples':[]}
    for doc in track(docs):
        
        d['text'].append(doc.text)


        d['labels'].append(doc._.labels)

        spans = []
        if ('all' in doc.spans) and len(doc.spans['all']) > 0:
            for span in doc.spans['all']:
                spans.append({'offset': (span.start_char, span.end_char), 'label': span.label_, 'text': span.text})
        d['spans'].append(spans)

        tokens = []
        if len(doc.ents) > 0:
            for token in doc:
                t = {'offset': (token.idx, token.idx+1), 'text': token.text}
                bio = token.ent_iob_ + '-' + token.ent_type_ if token.ent_iob_ != 'O' else token.ent_iob_
                t['label'] = bio
                tokens.append(t)
        d['tokens'].append(tokens)

        
        # if len(doc._.triples) > 0:
        triples = []
        for spo in doc._.spoes:
            sub = spo.subject
            pred = spo.predicate
            obj = spo.object
            triples.append({'subject': {'offset':(sub.start_char, sub.end_char), 'text':sub.text}, 'predicate': pred, 'object': {'offset':(obj.start_char, obj.end_char), 'text':obj.text}})
        d['triples'].append(triples)

    # if len(d['spans']) < 1:
    #     del d['spans']
    # if len(d['triples']) < 1:
    #     del d['triples']
    ds = Dataset
    # ds.features = dataset_features
    ds = ds.from_dict(d)
    return ds


if __name__ == "__main__":
    import spacy
    from spacy.tokens import Span
    nlp = spacy.blank('zh')
    doc = nlp(u'我是一个中国人')
    doc.spans['all'] = [Span(doc, 0, 1, label='PER'), Span(doc, 2, 3, label='PER'), Span(doc, 4, 5, label='PER')]
    # doc.set_ents([Span(doc, 2, 3, label='PER'), Span(doc, 4, 5, label='PER')])
    doc._.triples = [Triple((0, 1, 'PER', 2, 3)), Triple((2, 3, 'PER', 4, 5))]
    ds = convert_docs_to_dataset([doc])
    print(ds[0])