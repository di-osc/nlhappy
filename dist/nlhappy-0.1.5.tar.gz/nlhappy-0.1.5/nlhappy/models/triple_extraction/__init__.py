from .bert_gplinker import BertGPLinker

__all__ = ['BertGPLinker']